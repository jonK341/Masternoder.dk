"""
Agent Database Models
Life-like agents that copy user behaviors and generate tasks/skills/missions
"""
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy.sql import func
import json

# Import existing db instance
from src.db.models import db


class Agent(db.Model):
    """Agent profile - life-like agent that copies user behavior"""
    __tablename__ = 'agents'
    
    id = db.Column(db.String(36), primary_key=True)
    user_id = db.Column(db.String(100), nullable=False, index=True)
    agent_name = db.Column(db.String(200), nullable=False)
    agent_type = db.Column(db.String(50), default='personal_assistant')  # personal_assistant, creative_partner, strategist
    
    # Agent Levels (3 systems)
    level_system_1 = db.Column(db.Integer, default=1)  # Experience Level
    level_system_2 = db.Column(db.Integer, default=1)  # Skill Level
    level_system_3 = db.Column(db.Integer, default=1)  # Mission Level
    
    # Agent Stats
    total_tasks_completed = db.Column(db.Integer, default=0)
    total_skills_learned = db.Column(db.Integer, default=0)
    total_missions_accomplished = db.Column(db.Integer, default=0)
    total_points_earned = db.Column(db.Integer, default=0)
    
    # Behavior Copying
    behavior_pattern = db.Column(db.Text)  # JSON: copied user behaviors
    learning_rate = db.Column(db.Float, default=0.1)  # How fast agent learns
    personality_traits = db.Column(db.Text)  # JSON: personality characteristics
    
    # GPS Navigation
    current_location = db.Column(db.String(200))  # GPS coordinates or location name
    location_history = db.Column(db.Text)  # JSON: location tracking
    navigation_enabled = db.Column(db.Boolean, default=True)
    
    # Calendar System (10 levels)
    calendar_level = db.Column(db.Integer, default=1)  # 1-10
    calendar_data = db.Column(db.Text)  # JSON: giga calendar structure
    
    # Top Lists
    top100_tasks = db.Column(db.Text)  # JSON: Top 100 task list
    top50_skills = db.Column(db.Text)  # JSON: Top 50 skills
    top25_missions = db.Column(db.Text)  # JSON: Top 25 missions
    top10_achievements = db.Column(db.Text)  # JSON: Top 10 achievements
    
    # Unified Points Integration
    unified_points = db.Column(db.Text)  # JSON: all unified points for agent
    
    # Agent Effects
    effects = db.Column(db.Text)  # JSON: agent effects on system
    active_effects = db.Column(db.Text)  # JSON: currently active effects
    
    # Video Generation Integration
    video_generation_count = db.Column(db.Integer, default=0)
    video_generation_opinions = db.Column(db.Text)  # JSON: agent opinions on videos
    service_worker_coordination = db.Column(db.Text)  # JSON: coordination data
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=func.now())
    last_active = db.Column(db.DateTime, default=func.now(), onupdate=func.now())
    last_behavior_sync = db.Column(db.DateTime, default=func.now())
    
    # Metadata
    metadata = db.Column(db.Text)  # JSON: additional agent data
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert agent to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'agent_name': self.agent_name,
            'agent_type': self.agent_type,
            'levels': {
                'system_1': self.level_system_1,
                'system_2': self.level_system_2,
                'system_3': self.level_system_3
            },
            'stats': {
                'tasks_completed': self.total_tasks_completed,
                'skills_learned': self.total_skills_learned,
                'missions_accomplished': self.total_missions_accomplished,
                'points_earned': self.total_points_earned
            },
            'calendar_level': self.calendar_level,
            'current_location': self.current_location,
            'navigation_enabled': self.navigation_enabled,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_active': self.last_active.isoformat() if self.last_active else None
        }


class AgentTask(db.Model):
    """Agent tasks from Top100 list"""
    __tablename__ = 'agent_tasks'
    
    id = db.Column(db.String(36), primary_key=True)
    agent_id = db.Column(db.String(36), db.ForeignKey('agents.id'), nullable=False, index=True)
    task_name = db.Column(db.String(500), nullable=False)
    task_description = db.Column(db.Text)
    task_priority = db.Column(db.Integer, default=50)  # 1-100
    task_status = db.Column(db.String(50), default='pending')  # pending, in_progress, completed, cancelled
    task_category = db.Column(db.String(100))
    points_reward = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=func.now())
    completed_at = db.Column(db.DateTime)
    
    # Relationship
    agent = db.relationship('Agent', backref='tasks')


class AgentSkill(db.Model):
    """Agent skills from Top50 list"""
    __tablename__ = 'agent_skills'
    
    id = db.Column(db.String(36), primary_key=True)
    agent_id = db.Column(db.String(36), db.ForeignKey('agents.id'), nullable=False, index=True)
    skill_name = db.Column(db.String(200), nullable=False)
    skill_level = db.Column(db.Integer, default=1)
    skill_category = db.Column(db.String(100))
    skill_points = db.Column(db.Integer, default=0)
    learned_at = db.Column(db.DateTime, default=func.now())
    
    # Relationship
    agent = db.relationship('Agent', backref='skills')


class AgentMission(db.Model):
    """Agent missions from Top25 list"""
    __tablename__ = 'agent_missions'
    
    id = db.Column(db.String(36), primary_key=True)
    agent_id = db.Column(db.String(36), db.ForeignKey('agents.id'), nullable=False, index=True)
    mission_name = db.Column(db.String(500), nullable=False)
    mission_description = db.Column(db.Text)
    mission_type = db.Column(db.String(100))  # daily, weekly, monthly, special
    mission_status = db.Column(db.String(50), default='active')  # active, completed, failed
    mission_reward = db.Column(db.Integer, default=0)
    mission_requirements = db.Column(db.Text)  # JSON: requirements
    started_at = db.Column(db.DateTime, default=func.now())
    completed_at = db.Column(db.DateTime)
    
    # Relationship
    agent = db.relationship('Agent', backref='missions')


class AgentCalendarEvent(db.Model):
    """Agent calendar events (10 levels)"""
    __tablename__ = 'agent_calendar_events'
    
    id = db.Column(db.String(36), primary_key=True)
    agent_id = db.Column(db.String(36), db.ForeignKey('agents.id'), nullable=False, index=True)
    event_name = db.Column(db.String(500), nullable=False)
    event_description = db.Column(db.Text)
    event_level = db.Column(db.Integer, default=1)  # 1-10
    event_date = db.Column(db.DateTime, nullable=False)
    event_duration = db.Column(db.Integer)  # minutes
    event_type = db.Column(db.String(100))  # task, skill, mission, meeting, reminder
    event_location = db.Column(db.String(200))  # GPS or location name
    created_at = db.Column(db.DateTime, default=func.now())
    
    # Relationship
    agent = db.relationship('Agent', backref='calendar_events')


class AgentVideoOpinion(db.Model):
    """Agent opinions on video generation"""
    __tablename__ = 'agent_video_opinions'
    
    id = db.Column(db.String(36), primary_key=True)
    agent_id = db.Column(db.String(36), db.ForeignKey('agents.id'), nullable=False, index=True)
    video_id = db.Column(db.String(100), nullable=False, index=True)
    opinion_type = db.Column(db.String(50))  # quality, content, style, improvement
    opinion_text = db.Column(db.Text)
    opinion_score = db.Column(db.Float)  # 0.0-1.0
    suggestions = db.Column(db.Text)  # JSON: improvement suggestions
    created_at = db.Column(db.DateTime, default=func.now())
    
    # Relationship
    agent = db.relationship('Agent', backref='video_opinions')

