"""
Agent Routes - Agent system API endpoints
"""
from flask import Blueprint, request, jsonify
from backend.services.agent_system import agent_system
from src.utils.rate_limiter import rate_limit
import sys
import uuid

agent_bp = Blueprint('agent', __name__)

@agent_bp.route('/api/agent/create', methods=['POST'])
@agent_bp.route('/vidgenerator/api/agent/create', methods=['POST'])
@rate_limit()
def create_agent():
    """Create a new agent"""
    try:
        data = request.get_json() or {}
        user_id = data.get('user_id', 'default_user')
        agent_name = data.get('agent_name', 'My Agent')
        agent_type = data.get('agent_type', 'personal_assistant')
        
        agent = agent_system.create_agent(user_id, agent_name, agent_type)
        return jsonify({
            'success': True,
            'agent': agent
        }), 200
    except Exception as e:
        print(f"[Agent] Error creating agent: {e}", file=sys.stderr, flush=True)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/get', methods=['GET'])
@agent_bp.route('/vidgenerator/api/agent/get', methods=['GET'])
@rate_limit()
def get_agent():
    """Get agent data"""
    try:
        agent_id = request.args.get('agent_id')
        user_id = request.args.get('user_id')
        
        if agent_id:
            agent = agent_system.get_agent(agent_id)
            if agent:
                return jsonify({
                    'success': True,
                    'agent': agent
                }), 200
            else:
                return jsonify({
                    'success': False,
                    'error': 'Agent not found'
                }), 404
        elif user_id:
            agents = agent_system.get_user_agents(user_id)
            return jsonify({
                'success': True,
                'agents': agents
            }), 200
        else:
            return jsonify({
                'success': False,
                'error': 'agent_id or user_id required'
            }), 400
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/copy-behavior', methods=['POST'])
@agent_bp.route('/vidgenerator/api/agent/copy-behavior', methods=['POST'])
@rate_limit()
def copy_user_behavior():
    """Copy user behavior to agent"""
    try:
        data = request.get_json() or {}
        agent_id = data.get('agent_id')
        user_id = data.get('user_id', 'default_user')
        
        if not agent_id:
            return jsonify({
                'success': False,
                'error': 'agent_id required'
            }), 400
        
        behavior = agent_system.copy_user_behavior(agent_id, user_id)
        return jsonify({
            'success': True,
            'behavior_pattern': behavior
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/calendar', methods=['GET'])
@agent_bp.route('/vidgenerator/api/agent/calendar', methods=['GET'])
@rate_limit()
def get_calendar():
    """Get giga calendar for agent"""
    try:
        agent_id = request.args.get('agent_id')
        days = int(request.args.get('days', 30))
        
        if not agent_id:
            return jsonify({
                'success': False,
                'error': 'agent_id required'
            }), 400
        
        calendar = agent_system.get_giga_calendar(agent_id, days=days)
        return jsonify({
            'success': True,
            'calendar': calendar
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/video-opinion', methods=['POST'])
@agent_bp.route('/vidgenerator/api/agent/video-opinion', methods=['POST'])
@rate_limit()
def get_video_opinion():
    """Get agent opinion on video generation"""
    try:
        data = request.get_json() or {}
        agent_id = data.get('agent_id')
        video_id = data.get('video_id')
        video_data = data.get('video_data', {})
        
        if not agent_id or not video_id:
            return jsonify({
                'success': False,
                'error': 'agent_id and video_id required'
            }), 400
        
        # Generate agent opinion
        opinion = agent_system.generate_video_opinion(agent_id, video_id, video_data)
        return jsonify({
            'success': True,
            'opinion': opinion
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/top-lists', methods=['GET'])
@agent_bp.route('/vidgenerator/api/agent/top-lists', methods=['GET'])
@rate_limit()
def get_top_lists():
    """Get Top100/Top50/Top25/Top10 lists"""
    try:
        agent_id = request.args.get('agent_id')
        
        if not agent_id:
            return jsonify({
                'success': False,
                'error': 'agent_id required'
            }), 400
        
        agent = agent_system.get_agent(agent_id)
        if not agent:
            return jsonify({
                'success': False,
                'error': 'Agent not found'
            }), 404
        
        return jsonify({
            'success': True,
            'top100_tasks': agent.get('top100_tasks', []),
            'top50_skills': agent.get('top50_skills', []),
            'top25_missions': agent.get('top25_missions', []),
            'top10_achievements': agent.get('top10_achievements', [])
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/gps', methods=['POST'])
@agent_bp.route('/vidgenerator/api/agent/gps', methods=['POST'])
@rate_limit()
def update_gps_location():
    """Update agent GPS location"""
    try:
        data = request.get_json() or {}
        agent_id = data.get('agent_id')
        location = data.get('location')  # GPS coordinates or location name
        
        if not agent_id or not location:
            return jsonify({
                'success': False,
                'error': 'agent_id and location required'
            }), 400
        
        result = agent_system.update_gps_location(agent_id, location)
        return jsonify({
            'success': True,
            'location': result
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@agent_bp.route('/api/agent/coordinate', methods=['POST'])
@agent_bp.route('/vidgenerator/api/agent/coordinate', methods=['POST'])
@rate_limit()
def coordinate_agent():
    """Coordinate agent with service worker for production"""
    try:
        data = request.get_json() or {}
        agent_id = data.get('agent_id')
        video_id = data.get('video_id')
        production_data = data.get('production_data', {})
        
        if not agent_id or not video_id:
            return jsonify({
                'success': False,
                'error': 'agent_id and video_id required'
            }), 400
        
        coordination = agent_system.coordinate_with_service_worker(agent_id, video_id, production_data)
        return jsonify({
            'success': True,
            'coordination': coordination
        }), 200
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

