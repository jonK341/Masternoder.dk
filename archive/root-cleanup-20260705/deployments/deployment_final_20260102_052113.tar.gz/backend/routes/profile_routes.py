"""
Profile Routes - Name change and profile updates
"""
from flask import Blueprint, request, jsonify
from src.utils.rate_limiter import rate_limit
from datetime import datetime
import uuid
import sys

profile_api_bp = Blueprint('profile_api', __name__)

@profile_api_bp.route('/api/profile/update-name', methods=['POST'])
@profile_api_bp.route('/vidgenerator/api/profile/update-name', methods=['POST'])
@rate_limit()
def update_profile_name():
    """Update user display name"""
    try:
        data = request.get_json() or {}
        user_id = data.get('user_id', 'default_user')
        display_name = data.get('display_name', '').strip()
        
        if not display_name or len(display_name) < 2 or len(display_name) > 50:
            return jsonify({
                'success': False,
                'error': 'Display name must be between 2 and 50 characters'
            }), 400
        
        # Update in database
        try:
            from src.db.models import db, UserProfile
            with db.app.app_context():
                profile = UserProfile.query.filter_by(user_id=user_id).first()
                if profile:
                    profile.display_name = display_name
                    db.session.commit()
                else:
                    # Create new profile
                    profile = UserProfile(
                        id=str(uuid.uuid4()),
                        user_id=user_id,
                        display_name=display_name
                    )
                    db.session.add(profile)
                    db.session.commit()
        except Exception as db_err:
            print(f"[Profile] Database error (non-critical): {db_err}", file=sys.stderr, flush=True)
        
        # Save to JSON file
        import json
        import os
        profile_dir = 'data/user_profiles'
        os.makedirs(profile_dir, exist_ok=True)
        profile_file = os.path.join(profile_dir, f'{user_id}.json')
        
        profile_data = {}
        if os.path.exists(profile_file):
            with open(profile_file, 'r') as f:
                profile_data = json.load(f)
        
        profile_data['display_name'] = display_name
        profile_data['last_updated'] = datetime.utcnow().isoformat()
        
        with open(profile_file, 'w') as f:
            json.dump(profile_data, f, indent=2)
        
        return jsonify({
            'success': True,
            'display_name': display_name,
            'user_id': user_id
        }), 200
    except Exception as e:
        print(f"[Profile] Error: {e}", file=sys.stderr, flush=True)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

