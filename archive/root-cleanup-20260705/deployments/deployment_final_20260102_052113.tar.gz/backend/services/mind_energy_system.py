"""
Mind Energy System - HP/Mana style energy for generators
Like hit points and mana points for video generation
"""
from typing import Dict, Any, Optional
from datetime import datetime, timedelta
import json
import os

class MindEnergySystem:
    """
    Mind Energy System - Generator Energy (HP/Mana style)
    """
    
    def __init__(self):
        self.data_dir = 'data/mind_energy'
        os.makedirs(self.data_dir, exist_ok=True)
        self.max_energy = 100
        self.regeneration_rate = 1.0  # Energy per minute
        self.generator_cost = 20  # Cost per video generation
    
    def get_energy(self, user_id: str) -> Dict[str, Any]:
        """Get current mind energy for user"""
        energy_file = os.path.join(self.data_dir, f'{user_id}.json')
        
        if os.path.exists(energy_file):
            with open(energy_file, 'r') as f:
                data = json.load(f)
        else:
            data = {
                'generator_energy': self.max_energy,
                'max_energy': self.max_energy,
                'last_update': datetime.utcnow().isoformat(),
                'total_energy_used': 0,
                'total_energy_regenerated': 0
            }
        
        # Regenerate energy based on time passed
        last_update = datetime.fromisoformat(data.get('last_update', datetime.utcnow().isoformat()))
        time_passed = (datetime.utcnow() - last_update).total_seconds() / 60  # minutes
        energy_regenerated = time_passed * self.regeneration_rate
        
        current_energy = min(
            self.max_energy,
            data.get('generator_energy', self.max_energy) + energy_regenerated
        )
        
        # Update data
        data['generator_energy'] = current_energy
        data['max_energy'] = self.max_energy
        data['last_update'] = datetime.utcnow().isoformat()
        data['total_energy_regenerated'] = data.get('total_energy_regenerated', 0) + energy_regenerated
        
        # Save
        with open(energy_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {
            'generator_energy': current_energy,
            'max_energy': self.max_energy,
            'energy_percentage': (current_energy / self.max_energy) * 100,
            'regeneration_rate': self.regeneration_rate,
            'can_generate': current_energy >= self.generator_cost,
            'time_to_full': ((self.max_energy - current_energy) / self.regeneration_rate) if current_energy < self.max_energy else 0
        }
    
    def use_generator_energy(self, user_id: str, amount: int = None) -> Dict[str, Any]:
        """Use energy for generator"""
        if amount is None:
            amount = self.generator_cost
        
        energy_data = self.get_energy(user_id)
        current_energy = energy_data['generator_energy']
        
        if current_energy < amount:
            return {
                'success': False,
                'error': 'Insufficient energy',
                'current_energy': current_energy,
                'required': amount
            }
        
        # Deduct energy
        energy_file = os.path.join(self.data_dir, f'{user_id}.json')
        with open(energy_file, 'r') as f:
            data = json.load(f)
        
        data['generator_energy'] = current_energy - amount
        data['total_energy_used'] = data.get('total_energy_used', 0) + amount
        data['last_update'] = datetime.utcnow().isoformat()
        
        with open(energy_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {
            'success': True,
            'energy_used': amount,
            'remaining_energy': data['generator_energy'],
            'energy_percentage': (data['generator_energy'] / self.max_energy) * 100
        }
    
    def boost_energy(self, user_id: str, amount: int) -> Dict[str, Any]:
        """Boost energy (purchasable)"""
        energy_data = self.get_energy(user_id)
        current_energy = energy_data['generator_energy']
        
        energy_file = os.path.join(self.data_dir, f'{user_id}.json')
        with open(energy_file, 'r') as f:
            data = json.load(f)
        
        new_energy = min(self.max_energy, current_energy + amount)
        data['generator_energy'] = new_energy
        data['total_energy_boosted'] = data.get('total_energy_boosted', 0) + amount
        data['last_update'] = datetime.utcnow().isoformat()
        
        with open(energy_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        return {
            'success': True,
            'energy_boosted': amount,
            'current_energy': new_energy,
            'energy_percentage': (new_energy / self.max_energy) * 100
        }
    
    def upgrade_max_energy(self, user_id: str, new_max: int) -> Dict[str, Any]:
        """Upgrade max energy capacity"""
        energy_data = self.get_energy(user_id)
        
        energy_file = os.path.join(self.data_dir, f'{user_id}.json')
        with open(energy_file, 'r') as f:
            data = json.load(f)
        
        data['max_energy'] = new_max
        data['generator_energy'] = min(data['generator_energy'], new_max)
        data['last_update'] = datetime.utcnow().isoformat()
        
        with open(energy_file, 'w') as f:
            json.dump(data, f, indent=2)
        
        self.max_energy = new_max
        
        return {
            'success': True,
            'new_max_energy': new_max,
            'current_energy': data['generator_energy']
        }


# Global instance
mind_energy_system = MindEnergySystem()

