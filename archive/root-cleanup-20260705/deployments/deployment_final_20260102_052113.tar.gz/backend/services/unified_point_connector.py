"""
Unified Point Connector - Connects ALL point systems
Ensures every point system is integrated with unified system
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import os

class UnifiedPointConnector:
    """
    Connects ALL point systems to unified system
    """
    
    def __init__(self):
        self.connection_map = {
            # Core Systems
            'xp_system': {
                'module': 'backend.services.xp_system',
                'class': 'XPSystem',
                'method': 'get_user_profile',
                'point_keys': ['xp_total', 'level', 'xp_today', 'xp_this_week', 'xp_this_month']
            },
            'hunters_leveling': {
                'module': 'backend.services.hunters_leveling_system',
                'class': 'LevelingSystem',
                'method': 'get_user_stats',
                'point_keys': ['stats_points_total', 'stats_points_available', 'creativity_points', 'efficiency_points', 'quality_points', 'social_points', 'knowledge_points']
            },
            'activity_points': {
                'module': 'backend.services.activity_points_system',
                'class': 'ActivityPointsSystem',
                'method': 'get_user_stats',
                'point_keys': ['activity_points', 'total_points']
            },
            'theme_points': {
                'module': 'backend.services.theme_points_system',
                'class': 'ThemePointsSystem',
                'method': 'get_user_points',
                'point_keys': ['theme_points_total', 'theme_points_by_theme']
            },
            'chat_points': {
                'module': 'backend.services.chat_points',
                'class': 'ChatPoints',
                'method': 'get_user_points',
                'point_keys': ['chat_points', 'chat_messages']
            },
            'battle_system': {
                'module': 'backend.services.quick_battle_system',
                'class': 'QuickBattleSystem',
                'method': 'get_user_battle_stats',
                'point_keys': ['battle_points', 'battle_wins', 'battle_losses', 'battle_streak']
            },
            'achievements': {
                'module': 'backend.services.game_achievements',
                'class': 'GameAchievementSystem',
                'method': 'get_user_achievements',
                'point_keys': ['achievements_earned', 'achievement_points', 'achievements_total']
            },
            'trophies': {
                'module': 'backend.services.trophy_system',
                'class': 'TrophySystem',
                'method': 'get_user_trophies',
                'point_keys': ['trophies_collected', 'trophy_points', 'trophy_level']
            },
            'metal_systems': {
                'module': 'backend.services.enhanced_metal_systems',
                'class': 'EnhancedMetalSystems',
                'method': 'get_user_systems',
                'point_keys': ['territory_points', 'territory_level', 'sex_metal_points', 'sex_metal_level', 'porno_rights_points', 'porno_rights_level', 'mtg_points', 'mtg_level', 'trophy_hunt_points', 'trophy_hunt_level']
            },
            'social_points': {
                'module': 'backend.services.social_points_system',
                'class': 'SocialPointsSystem',
                'method': 'get_user_points',
                'point_keys': ['social_points_total', 'social_friendship_points', 'social_community_points', 'social_event_points']
            },
            'quest_points': {
                'module': 'backend.services.quest_system',
                'class': 'QuestSystem',
                'method': 'get_user_quests',
                'point_keys': ['quest_points', 'quest_xp', 'active_quests', 'completed_quests']
            },
            'generation_tracker': {
                'module': 'backend.services.generation_tracker',
                'class': 'GenerationTracker',
                'method': 'get_user_stats',
                'point_keys': ['videos_created', 'generations_total', 'high_quality_generations', 'average_quality_score']
            },
            'mind_energy': {
                'module': 'backend.services.mind_energy_system',
                'class': 'MindEnergySystem',
                'method': 'get_energy',
                'point_keys': ['generator_energy', 'max_energy', 'energy_percentage']
            }
        }
        self.data_dir = 'data/unified_points'
        os.makedirs(self.data_dir, exist_ok=True)
    
    def connect_all_systems(self, user_id: str) -> Dict[str, Any]:
        """Connect all point systems and return unified data"""
        all_points = {}
        connection_status = {}
        
        for system_name, system_info in self.connection_map.items():
            try:
                # Import module
                module = __import__(system_info['module'], fromlist=[''])
                
                # Get class instance
                if hasattr(module, system_info['class']):
                    system_class = getattr(module, system_info['class'])
                    if isinstance(system_class, type):
                        system_instance = system_class()
                    else:
                        system_instance = system_class
                    
                    # Call method
                    if hasattr(system_instance, system_info['method']):
                        method = getattr(system_instance, system_info['method'])
                        result = method(user_id)
                        
                        # Extract points
                        if isinstance(result, dict):
                            for key in system_info['point_keys']:
                                if key in result:
                                    all_points[key] = result[key]
                        
                        connection_status[system_name] = {
                            'connected': True,
                            'points_found': len([k for k in system_info['point_keys'] if k in (result or {})])
                        }
                    else:
                        connection_status[system_name] = {
                            'connected': False,
                            'error': f"Method {system_info['method']} not found"
                        }
                else:
                    connection_status[system_name] = {
                        'connected': False,
                        'error': f"Class {system_info['class']} not found"
                    }
            except Exception as e:
                connection_status[system_name] = {
                    'connected': False,
                    'error': str(e)
                }
        
        # Save unified points
        unified_file = os.path.join(self.data_dir, f'{user_id}.json')
        unified_data = {
            'user_id': user_id,
            'all_points': all_points,
            'connection_status': connection_status,
            'last_updated': datetime.utcnow().isoformat(),
            'total_systems': len(self.connection_map),
            'connected_systems': len([s for s in connection_status.values() if s.get('connected', False)])
        }
        
        with open(unified_file, 'w') as f:
            json.dump(unified_data, f, indent=2)
        
        return unified_data
    
    def get_unified_points(self, user_id: str) -> Dict[str, Any]:
        """Get unified points for user"""
        unified_file = os.path.join(self.data_dir, f'{user_id}.json')
        
        if os.path.exists(unified_file):
            with open(unified_file, 'r') as f:
                return json.load(f)
        
        # If not exists, connect all systems
        return self.connect_all_systems(user_id)


# Global instance
unified_point_connector = UnifiedPointConnector()

