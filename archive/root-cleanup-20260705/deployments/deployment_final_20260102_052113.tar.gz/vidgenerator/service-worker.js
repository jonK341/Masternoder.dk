const CACHE_NAME = 'vidgen-sw-v5-intelligence';
const OFFLINE_FALLBACK = '/vidgenerator/';
const PRECACHE_URLS = [
  '/vidgenerator/',
  '/vidgenerator/generator/',
  '/vidgenerator/static/css/style.css',
  '/vidgenerator/static/js/main.js',
  '/vidgenerator/static/css/graffiti-style.css'
];

// Tech Intelligence System
const intelligenceSystem = {
  cacheStrategy: 'intelligent',
  networkAware: true,
  performanceOptimized: true,
  predictiveCaching: true,
  
  // Intelligence metrics
  metrics: {
    cacheHitRate: 0,
    networkLatency: 0,
    performanceScore: 0,
    lastUpdate: Date.now()
  },
  
  // Smart cache management
  getCacheStrategy: function(url) {
    // API endpoints - network first
    if (url.includes('/api/')) {
      return 'network-first';
    }
    // Static assets - cache first
    if (url.match(/\.(css|js|png|jpg|jpeg|gif|svg|woff|woff2|ttf|eot)$/i)) {
      return 'cache-first';
    }
    // Pages - stale-while-revalidate
    return 'stale-while-revalidate';
  },
  
  // Update metrics
  updateMetrics: function(hit, latency) {
    this.metrics.cacheHitRate = (this.metrics.cacheHitRate * 0.9) + (hit ? 0.1 : 0);
    this.metrics.networkLatency = (this.metrics.networkLatency * 0.9) + (latency * 0.1);
    this.metrics.performanceScore = (this.metrics.cacheHitRate * 0.6) + ((1 - this.metrics.networkLatency / 1000) * 0.4);
    this.metrics.lastUpdate = Date.now();
  }
};

// Task rotation system
let currentTaskType = 'cache_management';
let taskRotationInterval = 300000; // 5 minutes
let lastTaskRotation = Date.now();
const taskTypes = ['cache_management', 'media_collection', 'background_sync', 'notification', 'data_collection', 'video_processing', 'api_call'];
let taskExecutionCount = 0;
const maxTasksBeforeRotation = 10;

// API endpoints that should NOT be cached (always fetch fresh)
const API_NO_CACHE = [
  '/api/generator/create',
  '/api/documentary/progress/',
  '/api/generator/ai-clips/',
  '/api/statistics',
  '/api/game/'
];

self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker v5 with intelligence...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching precache URLs with intelligence');
        return cache.addAll(PRECACHE_URLS);
      })
      .then(() => {
        console.log('[SW] Precache complete, skipping waiting');
        return self.skipWaiting();
      })
      .catch((err) => {
        console.error('[SW] Install error:', err);
      })
  );
});

self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker v2...');
  event.waitUntil(
    caches.keys().then((keys) => {
      const deletePromises = keys
        .filter((key) => key !== CACHE_NAME)
        .map((key) => {
          console.log('[SW] Deleting old cache:', key);
          return caches.delete(key);
        });
      return Promise.all(deletePromises);
    })
    .then(() => {
      console.log('[SW] Activation complete, claiming clients');
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle same-origin
  if (url.origin !== self.location.origin) return;

  // API endpoints - Network first, no cache
  const isApiNoCache = API_NO_CACHE.some(pattern => url.pathname.includes(pattern));
  if (isApiNoCache || request.method !== 'GET') {
    // For API calls and non-GET, always fetch from network
    event.respondWith(
      fetch(request)
        .catch(() => {
          // If offline, return offline response for API calls
          if (request.method === 'GET' && url.pathname.includes('/api/')) {
            return new Response(
              JSON.stringify({ 
                success: false, 
                error: 'Offline - API not available',
                offline: true 
              }),
              { 
                status: 503,
                headers: { 'Content-Type': 'application/json' }
              }
            );
          }
          throw new Error('Network error');
        })
    );
    return;
  }

  // Intelligent caching strategy
  taskExecutionCount++;
  rotateTask();
  
  const strategy = intelligenceSystem.getCacheStrategy(url.pathname);
  const startTime = performance.now();
  
  event.respondWith(
    (async () => {
      if (strategy === 'network-first') {
        // Network first for API calls
        try {
          const response = await fetch(request);
          intelligenceSystem.updateMetrics(false, performance.now() - startTime);
          return response;
        } catch (error) {
          // Fallback to cache if network fails
          const cached = await caches.match(request);
          if (cached) {
            intelligenceSystem.updateMetrics(true, 0);
            return cached;
          }
          throw error;
        }
      } else if (strategy === 'cache-first') {
        // Cache first for static assets
        const cached = await caches.match(request);
        if (cached) {
          intelligenceSystem.updateMetrics(true, 0);
          // Update cache in background
          if (currentTaskType === 'cache_management' || currentTaskType === 'background_sync') {
            fetch(request).then((response) => {
              if (response.ok) {
                const clone = response.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
              }
            }).catch(() => {});
          }
          return cached;
        }
        // Not cached, fetch from network
        const response = await fetch(request);
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        intelligenceSystem.updateMetrics(false, performance.now() - startTime);
        return response;
      } else {
        // Stale-while-revalidate for pages
        const cached = await caches.match(request);
        const fetchPromise = fetch(request).then((response) => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        });
        
        if (cached) {
          intelligenceSystem.updateMetrics(true, 0);
          fetchPromise.catch(() => {}); // Don't wait for update
          return cached;
        }
        
        intelligenceSystem.updateMetrics(false, performance.now() - startTime);
        return fetchPromise.catch(() => {
          // If offline and request is for a page, return offline fallback
          if (request.destination === 'document' || url.pathname.endsWith('/')) {
            return caches.match(OFFLINE_FALLBACK);
          }
          throw new Error('Network error');
        });
      }
    })()
  );
});

// Media collection for video generation
const collectedMedia = {
  images: [],
  audio: []
};

// Task rotation function
function rotateTask() {
  const now = Date.now();
  if (now - lastTaskRotation > taskRotationInterval || taskExecutionCount >= maxTasksBeforeRotation) {
    const currentIndex = taskTypes.indexOf(currentTaskType);
    const nextIndex = (currentIndex + 1) % taskTypes.length;
    currentTaskType = taskTypes[nextIndex];
    lastTaskRotation = now;
    taskExecutionCount = 0;
    console.log(`[SW] Task rotated to: ${currentTaskType}`);
    
    // Notify backend of rotation
    fetch('/vidgenerator/api/service-worker/task/create', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        task_type: currentTaskType,
        data: {rotation: true, timestamp: now}
      })
    }).catch(() => {});
  }
}

// Rotate tasks periodically
setInterval(rotateTask, taskRotationInterval);

// Handle messages from clients
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  // Task rotation message
  if (event.data && event.data.type === 'ROTATE_TASK') {
    rotateTask();
    event.ports[0].postMessage({success: true, currentTaskType: currentTaskType});
  }
  
  if (event.data && event.data.type === 'CACHE_URLS') {
    const urls = event.data.urls || [];
    event.waitUntil(
      caches.open(CACHE_NAME).then((cache) => {
        return Promise.all(urls.map(url => {
          return fetch(url).then(response => {
            if (response.ok) {
              return cache.put(url, response);
            }
          }).catch(() => {
            // Ignore fetch errors
          });
        }));
      })
    );
  }
  
  // Agent coordination for video generation
  if (event.data && event.data.type === 'AGENT_COORDINATION') {
    const coordinationData = event.data.data;
    const { agent_id, video_id, production_stage } = coordinationData;
    
    console.log('[SW] Agent coordination:', { agent_id, video_id, production_stage });
    
    // Coordinate with agent system
    fetch('/vidgenerator/api/agent/coordinate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        agent_id: agent_id,
        video_id: video_id,
        production_data: {
          stage: production_stage,
          service_worker_active: true,
          timestamp: Date.now()
        }
      })
    }).then(response => response.json()).then(data => {
      console.log('[SW] Agent coordination result:', data);
      // Notify client
      if (event.ports && event.ports[0]) {
        event.ports[0].postMessage({
          type: 'AGENT_COORDINATION_RESULT',
          data: data
        });
      }
    }).catch(err => {
      console.error('[SW] Agent coordination error:', err);
    });
  }
  
  // Handle media collection
  if (event.data && event.data.type === 'COLLECT_MEDIA') {
    const media = event.data.media;
    if (media.type === 'image') {
      collectedMedia.images.push({
        url: media.url,
        alt: media.alt || '',
        timestamp: Date.now()
      });
    } else if (media.type === 'audio') {
      collectedMedia.audio.push({
        url: media.url,
        duration: media.duration || 0,
        timestamp: Date.now()
      });
    }
    
    // Send collected media to backend
    sendMediaToBackend(media);
  }
  
  // Handle request for collected media
  if (event.data && event.data.type === 'GET_COLLECTED_MEDIA') {
    event.ports[0].postMessage({
      success: true,
      media: collectedMedia
    });
  }
  
  // Handle intelligence metrics request
  if (event.data && event.data.type === 'GET_INTELLIGENCE_METRICS') {
    event.ports[0].postMessage({
      success: true,
      metrics: intelligenceSystem.metrics,
      strategy: intelligenceSystem.cacheStrategy
    });
  }
  
  // Handle intelligence update
  if (event.data && event.data.type === 'UPDATE_INTELLIGENCE') {
    if (event.data.metrics) {
      Object.assign(intelligenceSystem.metrics, event.data.metrics);
    }
    if (event.data.strategy) {
      intelligenceSystem.cacheStrategy = event.data.strategy;
    }
    event.ports[0].postMessage({success: true});
  }
});

// Send media to backend
async function sendMediaToBackend(media) {
  try {
    await fetch('/vidgenerator/api/media/collect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(media)
    });
  } catch (error) {
    console.error('[SW] Error sending media to backend:', error);
  }
}

// Intercept image and audio requests to collect them
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Collect images
  if (url.pathname.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i)) {
    event.respondWith(
      fetch(event.request).then(response => {
        if (response.ok) {
          const media = {
            type: 'image',
            url: event.request.url,
            timestamp: Date.now()
          };
          
          // Send to backend
          sendMediaToBackend(media);
          
          // Store in collected media
          collectedMedia.images.push(media);
        }
        return response;
      })
    );
  }
  
  // Collect audio
  if (url.pathname.match(/\.(mp3|wav|ogg|m4a|aac)$/i)) {
    event.respondWith(
      fetch(event.request).then(response => {
        if (response.ok) {
          const media = {
            type: 'audio',
            url: event.request.url,
            timestamp: Date.now()
          };
          
          // Send to backend
          sendMediaToBackend(media);
          
          // Store in collected media
          collectedMedia.audio.push(media);
        }
        return response;
      })
    );
  }
});

