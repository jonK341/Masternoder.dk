"""
Register all Micro integration blueprints with Flask app
"""
import sys
import os

# Add backend directory to path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

# Safe print function for uWSGI (handles blocking writes)
def _safe_print(*args, **kwargs):
    """Print that handles BlockingIOError gracefully - use during app initialization"""
    try:
        # Use built-in print function, not recursive call
        print(*args, **kwargs)
    except (BlockingIOError, OSError) as e:
        # If we can't print, try to log to file
        try:
            log_dir = os.path.join(backend_dir, 'logs')
            os.makedirs(log_dir, exist_ok=True)
            with open(os.path.join(log_dir, 'blueprint_registration.log'), 'a') as f:
                f.write(' '.join(str(a) for a in args) + '\n')
        except:
            pass  # If we can't even log, silently continue

def register_all_blueprints(app):
    """Register all Micro integration blueprints"""
    _safe_print("[Backend] Registering Micro integration blueprints...")
    
    registered_count = 0
    
    # Debugger routes
    try:
        from backend.routes.debugger_page import debugger_page_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(debugger_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered debugger_page blueprint")
    except ImportError as e:
        _safe_print(f"  ⚠ Could not import debugger_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering debugger_page: {e}")
    
    try:
        from backend.routes.debugger_enhanced import debugger_enhanced_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(debugger_enhanced_bp)
        registered_count += 1
        _safe_print("  [OK] Registered debugger_enhanced blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import debugger_enhanced: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering debugger_enhanced: {e}")
    
    try:
        from backend.routes.comprehensive_debugger import comprehensive_debugger_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(comprehensive_debugger_bp)
        registered_count += 1
        _safe_print("  [OK] Registered comprehensive_debugger blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import comprehensive_debugger: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering comprehensive_debugger: {e}")
    
    try:
        from backend.routes.api_debugger import api_debugger_bp
        # No url_prefix - middleware already strips /vidgenerator, and routes have both paths
        app.register_blueprint(api_debugger_bp)
        registered_count += 1
        _safe_print("  [OK] Registered api_debugger blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import api_debugger: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering api_debugger: {e}")
    
    # URL Checker routes
    try:
        from backend.routes.url_checker_routes import url_checker_bp
        app.register_blueprint(url_checker_bp)
        registered_count += 1
        _safe_print("  [OK] Registered url_checker blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import url_checker_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering url_checker: {e}")
        import traceback
        traceback.print_exc()
    
    # Debugger Download routes
    try:
        from backend.routes.debugger_download import debugger_download_bp
        app.register_blueprint(debugger_download_bp)
        registered_count += 1
        _safe_print("  [OK] Registered debugger_download blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import debugger_download: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering debugger_download: {e}")
        import traceback
        traceback.print_exc()
    
    # Stats routes
    try:
        from backend.routes.stats import stats_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(stats_bp)
        registered_count += 1
        _safe_print("  [OK] Registered stats blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import stats: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering stats: {e}")
    
    try:
        from backend.routes.stats_summary import stats_summary_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(stats_summary_bp)
        registered_count += 1
        _safe_print("  [OK] Registered stats_summary blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import stats_summary: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering stats_summary: {e}")
    
    # Chat routes
    try:
        from backend.routes.chat import register_chat_routes
        register_chat_routes(app)
        registered_count += 1
        _safe_print("  [OK] Registered chat routes")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import chat routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering chat routes: {e}")
    
    try:
        from backend.routes.chat_enhanced import register_chat_enhanced_routes
        register_chat_enhanced_routes(app)
        registered_count += 1
        _safe_print("  [OK] Registered chat_enhanced routes")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import chat_enhanced: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering chat_enhanced: {e}")
    
    # Generator routes
    try:
        from backend.routes.generator import generator_bp
        # No url_prefix - routes are defined with both /api/generator/* and /vidgenerator/api/generator/* paths
        app.register_blueprint(generator_bp)
        registered_count += 1
        _safe_print("  [OK] Registered generator blueprint (routes support both /api and /vidgenerator/api paths)")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import generator: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering generator: {e}")
    
    # Batch generator routes
    try:
        from backend.routes.batch_generator import batch_generator_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(batch_generator_bp)
        registered_count += 1
        _safe_print("  [OK] Registered batch_generator blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import batch_generator: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering batch_generator: {e}")
    
    # Gallery routes
    try:
        from backend.routes.gallery import gallery_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(gallery_bp)
        registered_count += 1
        _safe_print("  [OK] Registered gallery blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import gallery: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering gallery: {e}")
    
    # Game routes
    try:
        from backend.routes.game import game_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(game_bp)
        registered_count += 1
        _safe_print("  [OK] Registered game blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import game: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering game: {e}")

    # Aggregator page routes - DISABLED: Using direct route in src/app.py instead
    # try:
    #     from backend.routes.aggregator_page import aggregator_page_bp
    #     # No url_prefix - middleware already strips /vidgenerator
    #     app.register_blueprint(aggregator_page_bp)
    #     registered_count += 1
    #     _safe_print("  [OK] Registered aggregator_page blueprint")
    # except ImportError as e:
    #     _safe_print(f"  [WARN] Could not import aggregator_page: {e}")
    # except Exception as e:
    #     _safe_print(f"  [ERROR] Error registering aggregator_page: {e}")
    _safe_print("  [SKIP] aggregator_page blueprint - using direct route in src/app.py")
    
    # Battle routes
    try:
        from backend.routes.battle import battle_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(battle_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battle blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battle: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battle: {e}")
    
    # Battle Arena Gear routes
    try:
        from backend.routes.battle_arena_gear_routes import battle_arena_gear_bp
        app.register_blueprint(battle_arena_gear_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battle_arena_gear blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battle_arena_gear_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battle_arena_gear: {e}")
    
    # Creative Time Machine 500+ routes
    try:
        from backend.routes.creative_timemashine_routes import creative_timemashine_bp
        app.register_blueprint(creative_timemashine_bp)
        registered_count += 1
        _safe_print("  [OK] Registered creative_timemashine blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import creative_timemashine_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering creative_timemashine: {e}")
    
    # Nudging & Fear Twister routes
    try:
        from backend.routes.nudging_fear_twister_routes import nudging_fear_twister_bp
        app.register_blueprint(nudging_fear_twister_bp)
        registered_count += 1
        _safe_print("  [OK] Registered nudging_fear_twister blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import nudging_fear_twister_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering nudging_fear_twister: {e}")
    
    # Future Tech Integration routes
    try:
        from backend.routes.future_tech_integration_routes import future_tech_integration_bp
        app.register_blueprint(future_tech_integration_bp)
        registered_count += 1
        _safe_print("  [OK] Registered future_tech_integration blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import future_tech_integration_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering future_tech_integration: {e}")
    
    # Scaling System routes (1.3 billion users)
    try:
        from backend.routes.scaling_routes import scaling_bp
        app.register_blueprint(scaling_bp)
        registered_count += 1
        _safe_print("  [OK] Registered scaling blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import scaling_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering scaling: {e}")
    
    # Future Tech Intelligence Upgrade routes
    try:
        from backend.routes.future_tech_intelligence_routes import future_tech_intel_bp
        app.register_blueprint(future_tech_intel_bp)
        registered_count += 1
        _safe_print("  [OK] Registered future_tech_intelligence blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import future_tech_intelligence_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering future_tech_intelligence: {e}")
    
    # Guild and Clan routes
    try:
        from backend.routes.guild_clan import guild_clan_bp
        app.register_blueprint(guild_clan_bp)
        registered_count += 1
        _safe_print("  [OK] Registered guild_clan blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import guild_clan: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering guild_clan: {e}")
    
    # Social routes
    try:
        from backend.routes.social import social_bp
        app.register_blueprint(social_bp)
        registered_count += 1
        _safe_print("  [OK] Registered social blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import social: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering social: {e}")
    
    # Items routes
    try:
        from backend.routes.items import items_bp
        app.register_blueprint(items_bp)
        registered_count += 1
        _safe_print("  [OK] Registered items blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import items: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering items: {e}")
    
    # Artifacts routes
    try:
        from backend.routes.artifacts import artifacts_bp
        app.register_blueprint(artifacts_bp)
        registered_count += 1
        _safe_print("  [OK] Registered artifacts blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import artifacts: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering artifacts: {e}")
    
    # Player Profiler routes
    try:
        from backend.routes.player_profiler import profiler_bp
        app.register_blueprint(profiler_bp)
        registered_count += 1
        _safe_print("  [OK] Registered player_profiler blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import player_profiler: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering player_profiler: {e}")
    
    # Profile page route
    try:
        from backend.routes.profile import profile_page_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(profile_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered profile_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import profile_page: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering profile_page: {e}")
        import traceback
        traceback.print_exc()
    
    # Enhanced Stats routes
    try:
        from backend.routes.enhanced_stats import enhanced_stats_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(enhanced_stats_bp)
        registered_count += 1
        _safe_print("  [OK] Registered enhanced_stats blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import enhanced_stats: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering enhanced_stats: {e}")
    
    # Hunters Game (Leveling System) routes
    try:
        from backend.routes.hunters_game import hunters_game_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(hunters_game_bp)
        registered_count += 1
        _safe_print("  [OK] Registered hunters_game blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import hunters_game: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering hunters_game: {e}")
    
    # Main vidgenerator landing page
    try:
        from backend.routes.vidgenerator_main import vidgenerator_main_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(vidgenerator_main_bp)
        registered_count += 1
        _safe_print("  [OK] Registered vidgenerator_main blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import vidgenerator_main: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering vidgenerator_main: {e}")
    
    # Register rettigheder blueprint
    try:
        from backend.routes.rettigheder import rettigheder_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(rettigheder_bp)
        registered_count += 1
        _safe_print("  [OK] Registered rettigheder blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import rettigheder: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering rettigheder: {e}")
    
    # Register categories blueprint
    try:
        from backend.routes.categories import categories_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(categories_bp)
        registered_count += 1
        _safe_print("  [OK] Registered categories blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import categories: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering categories: {e}")
    
    # Register debugger_builder blueprint
    try:
        from backend.routes.debugger_builder import debugger_builder_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(debugger_builder_bp)
        registered_count += 1
        _safe_print("  [OK] Registered debugger_builder blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import debugger_builder: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering debugger_builder: {e}")
    
    # Register ai_debugger blueprint
    try:
        from backend.routes.ai_debugger import ai_debugger_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(ai_debugger_bp)
        registered_count += 1
        _safe_print("  [OK] Registered ai_debugger blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import ai_debugger: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering ai_debugger: {e}")
    
    # Register social_actions blueprint
    try:
        from backend.routes.social_actions import social_actions_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(social_actions_bp)
        registered_count += 1
        _safe_print("  [OK] Registered social_actions blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import social_actions: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering social_actions: {e}")
    
    
    # Register daily_activities blueprint
    try:
        from backend.routes.daily_activities import daily_activities_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(daily_activities_bp)
        registered_count += 1
        _safe_print("  [OK] Registered daily_activities blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import daily_activities: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering daily_activities: {e}")
    
    # Analytics routes
    try:
        from backend.routes.analytics import analytics_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(analytics_bp)
        registered_count += 1
        _safe_print("  [OK] Registered analytics blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import analytics: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering analytics: {e}")
    
    # Register database health check blueprint
    try:
        from src.db.health_check import health_check_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(health_check_bp)
        registered_count += 1
        _safe_print("  [OK] Registered database health_check blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import health_check: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering health_check: {e}")
    
    # Click Tracking routes
    try:
        from backend.routes.click_tracking import click_tracking_bp
        app.register_blueprint(click_tracking_bp)
        registered_count += 1
        _safe_print("  [OK] Registered click_tracking blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import click_tracking: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering click_tracking: {e}")
    
    # Hardcore AI Metal Magi routes
    try:
        from backend.routes.hardcore_ai_metal import hardcore_ai_metal_bp
        app.register_blueprint(hardcore_ai_metal_bp)
        registered_count += 1
        _safe_print("  [OK] Registered hardcore_ai_metal blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import hardcore_ai_metal: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering hardcore_ai_metal: {e}")
    
    # Special Stats routes
    try:
        from backend.routes.special_stats import special_stats_bp
        app.register_blueprint(special_stats_bp)
        registered_count += 1
        _safe_print("  [OK] Registered special_stats blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import special_stats: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering special_stats: {e}")
    
    # Hash System routes
    try:
        from backend.routes.hash_system import hash_system_bp
        app.register_blueprint(hash_system_bp)
        registered_count += 1
        _safe_print("  [OK] Registered hash_system blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import hash_system: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering hash_system: {e}")
    
    # Brand New Features routes
    try:
        from backend.routes.brand_new_features import brand_new_features_bp
        app.register_blueprint(brand_new_features_bp)
        registered_count += 1
        _safe_print("  [OK] Registered brand_new_features blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import brand_new_features: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering brand_new_features: {e}")
    
    # Themes routes
    try:
        from backend.routes.themes import themes_bp
        app.register_blueprint(themes_bp)
        registered_count += 1
        _safe_print("  [OK] Registered themes blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import themes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering themes: {e}")
    
    # Guild and Clan routes
    try:
        from backend.routes.guild_clan import guild_clan_bp
        app.register_blueprint(guild_clan_bp)
        registered_count += 1
        _safe_print("  [OK] Registered guild_clan blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import guild_clan: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering guild_clan: {e}")
    
    # Guild vs Clan BattleGrounds routes
    try:
        from backend.routes.guild_vs_clan_battlegrounds import battlegrounds_bp
        app.register_blueprint(battlegrounds_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battlegrounds blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battlegrounds: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battlegrounds: {e}")
    
    # BattleGrounds page route
    try:
        from backend.routes.battlegrounds_page import battlegrounds_page_bp
        app.register_blueprint(battlegrounds_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battlegrounds_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battlegrounds_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battlegrounds_page: {e}")
    
    # Champions League page route
    try:
        from backend.routes.champions_league_page import champions_league_page_bp
        app.register_blueprint(champions_league_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered champions_league_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import champions_league_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering champions_league_page: {e}")
    
    # VoldsRøv Stats routes
    try:
        from backend.routes.voldsrov_stats import voldsrov_stats_bp
        app.register_blueprint(voldsrov_stats_bp)
        registered_count += 1
        _safe_print("  [OK] Registered voldsrov_stats blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import voldsrov_stats: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering voldsrov_stats: {e}")
    
    # Enhanced Trophy Hunter routes
    try:
        from backend.routes.trophy_hunter_enhanced import trophy_hunter_enhanced_bp
        app.register_blueprint(trophy_hunter_enhanced_bp)
        registered_count += 1
        _safe_print("  [OK] Registered trophy_hunter_enhanced blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import trophy_hunter_enhanced: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering trophy_hunter_enhanced: {e}")
    
    # Enhanced Metal Systems routes
    try:
        from backend.routes.enhanced_metal_systems import enhanced_metal_bp
        app.register_blueprint(enhanced_metal_bp)
        registered_count += 1
        _safe_print("  [OK] Registered enhanced_metal_systems blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import enhanced_metal_systems: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering enhanced_metal_systems: {e}")
    
    # Space-Time Battlegrounds routes
    try:
        from backend.routes.space_time_battlegrounds import space_time_bp
        app.register_blueprint(space_time_bp)
        registered_count += 1
        _safe_print("  [OK] Registered space_time_battlegrounds blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import space_time_battlegrounds: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering space_time_battlegrounds: {e}")
    
    # KrimeTime WarZone routes
    try:
        from backend.routes.krimetime_warzone import krimetime_bp
        app.register_blueprint(krimetime_bp)
        registered_count += 1
        _safe_print("  [OK] Registered krimetime_warzone blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import krimetime_warzone: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering krimetime_warzone: {e}")
    
    # Error Hash Tracking routes
    try:
        from backend.routes.error_hash_tracking import error_hash_bp
        app.register_blueprint(error_hash_bp)
        registered_count += 1
        _safe_print("  [OK] Registered error_hash_tracking blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import error_hash_tracking: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering error_hash_tracking: {e}")
    
    # Theme Points routes
    try:
        from backend.routes.theme_points import theme_points_bp
        app.register_blueprint(theme_points_bp)
        registered_count += 1
        _safe_print("  [OK] Registered theme_points blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import theme_points: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering theme_points: {e}")
    
    # Battle & Hunt Video Integration routes
    try:
        from backend.routes.battle_hunt_video import battle_hunt_video_bp
        app.register_blueprint(battle_hunt_video_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battle_hunt_video blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battle_hunt_video: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battle_hunt_video: {e}")
    
    # AI Video and Clip Generation routes
    try:
        from backend.routes.ai_video_clip_routes import ai_video_clip_bp
        app.register_blueprint(ai_video_clip_bp)
        registered_count += 1
        _safe_print("  [OK] Registered ai_video_clip blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import ai_video_clip_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering ai_video_clip: {e}")
    
    # Video Generation Calculator routes
    try:
        from backend.routes.video_generation_calculator_routes import calculator_bp
        app.register_blueprint(calculator_bp)
        registered_count += 1
        _safe_print("  [OK] Registered video_generation_calculator blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import video_generation_calculator_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering video_generation_calculator: {e}")
    
    # Jons ID Metal routes
    try:
        from backend.routes.jons_id_metal_routes import jons_id_metal_bp
        app.register_blueprint(jons_id_metal_bp)
        registered_count += 1
        _safe_print("  [OK] Registered jons_id_metal blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import jons_id_metal_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering jons_id_metal: {e}")
    
    # WarZone Time Pocket routes
    try:
        from backend.routes.warzone_timepocket_routes import warzone_timepocket_bp
        app.register_blueprint(warzone_timepocket_bp)
        registered_count += 1
        _safe_print("  [OK] Registered warzone_timepocket blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import warzone_timepocket_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering warzone_timepocket: {e}")
    
    # Mission Controller routes
    try:
        from backend.routes.mission_controller_routes import mission_controller_bp
        app.register_blueprint(mission_controller_bp)
        registered_count += 1
        _safe_print("  [OK] Registered mission_controller blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import mission_controller_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering mission_controller: {e}")
    
    # Jukebox Money System routes
    try:
        from backend.routes.jukebox_money_routes import jukebox_money_bp
        app.register_blueprint(jukebox_money_bp)
        registered_count += 1
        _safe_print("  [OK] Registered jukebox_money blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import jukebox_money_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering jukebox_money: {e}")
    
    # Death Portal Manager routes (Two Portals)
    try:
        from backend.routes.death_portal_manager_routes import death_portal_manager_bp
        app.register_blueprint(death_portal_manager_bp)
        registered_count += 1
        _safe_print("  [OK] Registered death_portal_manager blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import death_portal_manager_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering death_portal_manager: {e}")
    
    # Dashboard page route
    try:
        from backend.routes.dashboard_page import dashboard_page_bp
        app.register_blueprint(dashboard_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered dashboard_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import dashboard_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering dashboard_page: {e}")
    
    # Time Disorder Device and Advanced Battle Tech routes
    try:
        from backend.routes.time_disorder_battle_routes import time_disorder_battle_bp
        app.register_blueprint(time_disorder_battle_bp)
        registered_count += 1
        _safe_print("  [OK] Registered time_disorder_battle blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import time_disorder_battle_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering time_disorder_battle: {e}")
    
    # Aggregator routes
    try:
        from backend.routes.aggregator_routes import aggregator_bp
        app.register_blueprint(aggregator_bp)
        registered_count += 1
        _safe_print("  [OK] Registered aggregator blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import aggregator_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering aggregator_routes: {e}")
    
    # Guild Management routes
    try:
        from backend.routes.guild_management import guild_management_bp
        app.register_blueprint(guild_management_bp)
        registered_count += 1
        _safe_print("  [OK] Registered guild_management blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import guild_management: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering guild_management: {e}")
    
    # Unified Points routes
    try:
        from backend.routes.unified_points import unified_points_bp
        app.register_blueprint(unified_points_bp)
        registered_count += 1
        _safe_print("  [OK] Registered unified_points blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import unified_points: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering unified_points: {e}")
    
    # Unified Points Reconstructed routes
    try:
        from backend.routes.unified_points_reconstructed import unified_points_reconstructed_bp
        app.register_blueprint(unified_points_reconstructed_bp)
        registered_count += 1
        _safe_print("  [OK] Registered unified_points_reconstructed blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import unified_points_reconstructed: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering unified_points_reconstructed: {e}")
    
    # Unified Point Connector routes
    try:
        from backend.routes.unified_point_connector_routes import unified_connector_bp
        app.register_blueprint(unified_connector_bp)
        registered_count += 1
        _safe_print("  [OK] Registered unified_point_connector blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import unified_point_connector_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering unified_point_connector: {e}")
    
    # Mind Energy routes
    try:
        from backend.routes.mind_energy_routes import mind_energy_bp
        app.register_blueprint(mind_energy_bp)
        registered_count += 1
        _safe_print("  [OK] Registered mind_energy blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import mind_energy_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering mind_energy: {e}")
    
    # Battle Tech Tree routes
    try:
        from backend.routes.battle_tech_tree_routes import battle_tech_tree_bp
        app.register_blueprint(battle_tech_tree_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battle_tech_tree blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battle_tech_tree_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battle_tech_tree: {e}")
    
    # Metal Page routes
    try:
        from backend.routes.metal_page import metal_page_bp
        app.register_blueprint(metal_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered metal_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import metal_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering metal_page: {e}")
    
    # Theme Points Page routes
    try:
        from backend.routes.theme_points_page import theme_points_page_bp
        app.register_blueprint(theme_points_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered theme_points_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import theme_points_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering theme_points_page: {e}")
    
    # Video Editor Page routes
    try:
        from backend.routes.video_editor_page import video_editor_page_bp
        app.register_blueprint(video_editor_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered video_editor_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import video_editor_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering video_editor_page: {e}")
        traceback.print_exc()
    
    # Dashboard Page routes
    try:
        from backend.routes.dashboard_page import dashboard_page_bp
        app.register_blueprint(dashboard_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered dashboard_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import dashboard_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering dashboard_page: {e}")
    
    # Activity Points Page routes
    try:
        from backend.routes.activity_points_page import activity_points_page_bp
        app.register_blueprint(activity_points_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered activity_points_page blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import activity_points_page: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering activity_points_page: {e}")
    
    # Activity Points routes
    try:
        _safe_print("  [DEBUG] Attempting to import activity_points_routes...")
        from backend.routes.activity_points_routes import activity_points_bp
        _safe_print(f"  [DEBUG] Imported activity_points_bp: {activity_points_bp}")
        app.register_blueprint(activity_points_bp)
        registered_count += 1
        _safe_print("  [OK] Registered activity_points blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import activity_points_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering activity_points: {e}")
        import traceback
        traceback.print_exc()
    
    # Battle Intelligence routes
    try:
        _safe_print("  [DEBUG] Attempting to import battle_intelligence_routes...")
        from backend.routes.battle_intelligence_routes import battle_intelligence_bp
        _safe_print(f"  [DEBUG] Imported battle_intelligence_bp: {battle_intelligence_bp}")
        app.register_blueprint(battle_intelligence_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battle_intelligence blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battle_intelligence_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battle_intelligence: {e}")
        import traceback
        traceback.print_exc()
    
    # Adaptive Difficulty routes
    try:
        _safe_print("  [DEBUG] Attempting to import adaptive_difficulty_routes...")
        from backend.routes.adaptive_difficulty_routes import adaptive_difficulty_bp
        _safe_print(f"  [DEBUG] Imported adaptive_difficulty_bp: {adaptive_difficulty_bp}")
        app.register_blueprint(adaptive_difficulty_bp)
        registered_count += 1
        _safe_print("  [OK] Registered adaptive_difficulty blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import adaptive_difficulty_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering adaptive_difficulty: {e}")
        import traceback
        traceback.print_exc()
    
    # Behavior Pattern Tracking routes
    try:
        _safe_print("  [DEBUG] Attempting to import behavior_pattern_routes...")
        from backend.routes.behavior_pattern_routes import behavior_pattern_bp
        _safe_print(f"  [DEBUG] Imported behavior_pattern_bp: {behavior_pattern_bp}")
        app.register_blueprint(behavior_pattern_bp)
        registered_count += 1
        _safe_print("  [OK] Registered behavior_pattern blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import behavior_pattern_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering behavior_pattern: {e}")
        import traceback
        traceback.print_exc()
    
    # Phase 3 routes (Hypnotic Effects & Pattern Recognition)
    try:
        _safe_print("  [DEBUG] Attempting to import phase3_routes...")
        from backend.routes.phase3_routes import phase3_bp
        _safe_print(f"  [DEBUG] Imported phase3_bp: {phase3_bp}")
        app.register_blueprint(phase3_bp)
        registered_count += 1
        _safe_print("  [OK] Registered phase3 blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import phase3_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering phase3: {e}")
        import traceback
        traceback.print_exc()
    
    # Point Connection routes
    try:
        _safe_print("  [DEBUG] Attempting to import point_connection_routes...")
        from backend.routes.point_connection_routes import point_connection_bp
        _safe_print(f"  [DEBUG] Imported point_connection_bp: {point_connection_bp}")
        app.register_blueprint(point_connection_bp)
        registered_count += 1
        _safe_print("  [OK] Registered point_connection blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import point_connection_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering point_connection: {e}")
        import traceback
        traceback.print_exc()
    
    # Quick Battle routes
    try:
        _safe_print("  [DEBUG] Attempting to import quick_battle_routes...")
        from backend.routes.quick_battle_routes import quick_battle_bp
        _safe_print(f"  [DEBUG] Imported quick_battle_bp: {quick_battle_bp}")
        app.register_blueprint(quick_battle_bp)
        registered_count += 1
        _safe_print("  [OK] Registered quick_battle blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import quick_battle_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering quick_battle: {e}")
        import traceback
        traceback.print_exc()
    
    # Champions League routes
    try:
        _safe_print("  [DEBUG] Attempting to import champions_league_routes...")
        from backend.routes.champions_league_routes import champions_league_bp
        _safe_print(f"  [DEBUG] Imported champions_league_bp: {champions_league_bp}")
        app.register_blueprint(champions_league_bp)
        registered_count += 1
        _safe_print("  [OK] Registered champions_league blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import champions_league_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering champions_league: {e}")
        import traceback
        traceback.print_exc()
    
    # Shop v2 routes
    try:
        _safe_print("  [DEBUG] Attempting to import shop_v2_routes...")
        from backend.routes.shop_v2_routes import shop_v2_bp
        _safe_print(f"  [DEBUG] Imported shop_v2_bp: {shop_v2_bp}")
        app.register_blueprint(shop_v2_bp)
        registered_count += 1
        _safe_print("  [OK] Registered shop_v2 blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import shop_v2_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering shop_v2: {e}")
        import traceback
        traceback.print_exc()
    
    # Tech Intelligence routes
    try:
        _safe_print("  [DEBUG] Attempting to import tech_intelligence_routes...")
        from backend.routes.tech_intelligence_routes import tech_intelligence_bp
        _safe_print(f"  [DEBUG] Imported tech_intelligence_bp: {tech_intelligence_bp}")
        app.register_blueprint(tech_intelligence_bp)
        registered_count += 1
        _safe_print("  [OK] Registered tech_intelligence blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import tech_intelligence_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering tech_intelligence: {e}")
        import traceback
        traceback.print_exc()
    
    # Complete Point Equation routes
    try:
        _safe_print("  [DEBUG] Attempting to import complete_point_equation_routes...")
        from backend.routes.complete_point_equation_routes import complete_equation_bp
        _safe_print(f"  [DEBUG] Imported complete_equation_bp: {complete_equation_bp}")
        app.register_blueprint(complete_equation_bp)
        registered_count += 1
        _safe_print("  [OK] Registered complete_equation blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import complete_point_equation_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering complete_equation: {e}")
        import traceback
        traceback.print_exc()
    
    # Intelligence Aggregator routes
    try:
        _safe_print("  [DEBUG] Attempting to import intelligence_aggregator_routes...")
        from backend.routes.intelligence_aggregator_routes import intelligence_aggregator_bp
        _safe_print(f"  [DEBUG] Imported intelligence_aggregator_bp: {intelligence_aggregator_bp}")
        app.register_blueprint(intelligence_aggregator_bp)
        registered_count += 1
        _safe_print("  [OK] Registered intelligence_aggregator blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import intelligence_aggregator_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering intelligence_aggregator: {e}")
        import traceback
        traceback.print_exc()
    
    # Beta Tester routes
    try:
        _safe_print("  [DEBUG] Attempting to import beta_tester_routes...")
        from backend.routes.beta_tester_routes import beta_tester_bp
        _safe_print(f"  [DEBUG] Imported beta_tester_bp: {beta_tester_bp}")
        app.register_blueprint(beta_tester_bp)
        registered_count += 1
        _safe_print("  [OK] Registered beta_tester blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import beta_tester_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering beta_tester: {e}")
        import traceback
        traceback.print_exc()
    
    # Rewards v2 routes
    try:
        from backend.routes.rewards_routes_v2 import rewards_v2_bp
        app.register_blueprint(rewards_v2_bp)
        registered_count += 1
        _safe_print("  [OK] Registered rewards_v2 blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register rewards_v2: {e}")
    
    # Quest routes
    try:
        from backend.routes.quest_routes import quest_bp
        app.register_blueprint(quest_bp)
        registered_count += 1
        _safe_print("  [OK] Registered quest blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register quest: {e}")
    
    # Quest page
    try:
        from backend.routes.quest_page import quest_page_bp
        app.register_blueprint(quest_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered quest_page blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register quest_page: {e}")
    
    # Real-time routes
    try:
        from backend.routes.realtime_routes import realtime_bp
        app.register_blueprint(realtime_bp)
        registered_count += 1
        _safe_print("  [OK] Registered realtime blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register realtime: {e}")
    
    # Analytics routes
    try:
        from backend.routes.analytics_routes import analytics_bp
        app.register_blueprint(analytics_bp)
        registered_count += 1
        _safe_print("  [OK] Registered analytics blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register analytics: {e}")
    
    # Time achievement guides routes
    try:
        from backend.routes.time_achievement_guides_routes import time_guides_bp
        app.register_blueprint(time_guides_bp)
        registered_count += 1
        _safe_print("  [OK] Registered time_achievement_guides blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register time_achievement_guides: {e}")
    
    # Time achievement guides page
    try:
        from backend.routes.time_achievement_guides_page import time_guides_page_bp
        app.register_blueprint(time_guides_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered time_achievement_guides_page blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register time_achievement_guides_page: {e}")
    
    # Milky Way Galaxy Research Station routes
    try:
        from backend.routes.milkyway_routes import milkyway_bp
        app.register_blueprint(milkyway_bp)
        registered_count += 1
        _safe_print("  [OK] Registered milkyway blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register milkyway: {e}")
    
    # Intelligent Points routes
    try:
        from backend.routes.intelligent_points_routes import intelligent_points_bp
        app.register_blueprint(intelligent_points_bp)
        registered_count += 1
        _safe_print("  [OK] Registered intelligent_points blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register intelligent_points: {e}")
    
    # Academic Perspective routes
    try:
        from backend.routes.academic_perspective_routes import academic_perspective_bp
        app.register_blueprint(academic_perspective_bp)
        registered_count += 1
        _safe_print("  [OK] Registered academic_perspective blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register academic_perspective: {e}")
    
    # Academic Perspective page
    try:
        from backend.routes.academic_perspective_page import academic_perspective_page_bp
        app.register_blueprint(academic_perspective_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered academic_perspective_page blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register academic_perspective_page: {e}")
    
    # OFC API routes
    try:
        from backend.routes.ofc_api_routes import ofc_api_bp
        app.register_blueprint(ofc_api_bp)
        registered_count += 1
        _safe_print("  [OK] Registered ofc_api blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register ofc_api: {e}")
    
    # Rights and Law routes
    try:
        from backend.routes.rights_law_routes import rights_law_bp
        app.register_blueprint(rights_law_bp)
        registered_count += 1
        _safe_print("  [OK] Registered rights_law blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register rights_law: {e}")
    
    # Rights and Law page
    try:
        from backend.routes.rights_law_page import rights_law_page_bp
        app.register_blueprint(rights_law_page_bp)
        registered_count += 1
        _safe_print("  [OK] Registered rights_law_page blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register rights_law_page: {e}")
    
    # AI Intelligence routes
    try:
        from backend.routes.ai_intelligence_routes import ai_intelligence_bp
        app.register_blueprint(ai_intelligence_bp)
        registered_count += 1
        _safe_print("  [OK] Registered ai_intelligence blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register ai_intelligence: {e}")
    
    # Point System Repair routes
    try:
        from backend.routes.point_system_repair_routes import point_repair_bp
        app.register_blueprint(point_repair_bp)
        registered_count += 1
        _safe_print("  [OK] Registered point_repair blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register point_repair: {e}")
    
    # Agent Task Force routes
    try:
        from backend.routes.agent_task_force_routes import agent_task_force_bp
        app.register_blueprint(agent_task_force_bp)
        registered_count += 1
        _safe_print("  [OK] Registered agent_task_force blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register agent_task_force: {e}")
    
    # Progression Triggers routes
    try:
        from backend.routes.progression_triggers_routes import progression_triggers_bp
        app.register_blueprint(progression_triggers_bp)
        registered_count += 1
        _safe_print("  [OK] Registered progression_triggers blueprint")
    except Exception as e:
        _safe_print(f"  [WARN] Could not register progression_triggers: {e}")
    
    # Parent Controls routes
    try:
        from backend.routes.parent_controls_routes import parent_controls_bp
        app.register_blueprint(parent_controls_bp)
        registered_count += 1
        _safe_print("  [OK] Registered parent_controls blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import parent_controls_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering parent_controls: {e}")
        import traceback
        traceback.print_exc()
    
    # Point Control Board routes (Scalable Dashboard System)
    try:
        from backend.routes.point_control_board_routes import point_control_board_bp
        app.register_blueprint(point_control_board_bp)
        registered_count += 1
        _safe_print("  [OK] Registered point_control_board blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import point_control_board_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering point_control_board: {e}")
        import traceback
        traceback.print_exc()
    
    # 178 Systems routes (Leaderboards, Achievements, Shop)
    try:
        from backend.routes.systems_178_routes import systems_178_bp
        app.register_blueprint(systems_178_bp)
        registered_count += 1
        _safe_print("  [OK] Registered systems_178 blueprint")
    except ImportError:
        try:
            from backend.routes.systems_178_routes import systems_178_bp
            app.register_blueprint(systems_178_bp)
            registered_count += 1
            _safe_print("  [OK] Registered systems_178 blueprint (alternative)")
        except ImportError as e:
            _safe_print(f"  [WARN] Could not import systems_178_routes: {e}")
            import traceback
            traceback.print_exc()
        except Exception as e:
            _safe_print(f"  [ERROR] Error registering systems_178: {e}")
            import traceback
            traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering systems_178: {e}")
        import traceback
        traceback.print_exc()
    
    # Advanced Intelligent Calculator routes
    try:
        from backend.routes.advanced_calculator_routes import advanced_calculator_bp
        app.register_blueprint(advanced_calculator_bp)
        registered_count += 1
        _safe_print("  [OK] Registered advanced_calculator blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import advanced_calculator_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering advanced_calculator: {e}")
        import traceback
        traceback.print_exc()
    
    # Agent Event Listeners and Error Handlers routes
    try:
        from backend.routes.agent_listeners_handlers_routes import agent_listeners_bp
        app.register_blueprint(agent_listeners_bp)
        registered_count += 1
        _safe_print("  [OK] Registered agent_listeners blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import agent_listeners_handlers_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering agent_listeners: {e}")
        import traceback
        traceback.print_exc()
    
    # Calculator Automation routes
    try:
        from backend.routes.calculator_automation_routes import calculator_automation_bp
        app.register_blueprint(calculator_automation_bp)
        registered_count += 1
        _safe_print("  [OK] Registered calculator_automation blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import calculator_automation_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering calculator_automation: {e}")
        import traceback
        traceback.print_exc()
    
    # Beta Testing routes
    try:
        from backend.routes.beta_testing_routes import beta_testing_bp
        app.register_blueprint(beta_testing_bp)
        registered_count += 1
        _safe_print("  [OK] Registered beta_testing blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import beta_testing_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering beta_testing: {e}")
        import traceback
        traceback.print_exc()
    
    # Shop v3 Ultimate routes
    try:
        from backend.routes.shop_v3_routes import shop_v3_bp
        app.register_blueprint(shop_v3_bp)
        registered_count += 1
        _safe_print("  [OK] Registered shop_v3 blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import shop_v3_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering shop_v3: {e}")
        import traceback
        traceback.print_exc()
    
    # Battle v3 Ultimate routes
    try:
        from backend.routes.battle_v3_routes import battle_v3_bp
        app.register_blueprint(battle_v3_bp)
        registered_count += 1
        _safe_print("  [OK] Registered battle_v3 blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import battle_v3_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering battle_v3: {e}")
        import traceback
        traceback.print_exc()
    
    # VidGenerator v3 Ultimate routes
    try:
        from backend.routes.vidgenerator_v3_routes import vidgenerator_v3_bp
        app.register_blueprint(vidgenerator_v3_bp)
        registered_count += 1
        _safe_print("  [OK] Registered vidgenerator_v3 blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import vidgenerator_v3_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering vidgenerator_v3: {e}")
        import traceback
        traceback.print_exc()
    
    # 178 Systems Knowledge & Intelligence routes
    try:
        from backend.routes.knowledge_intelligence_routes import knowledge_intelligence_bp
        app.register_blueprint(knowledge_intelligence_bp)
        registered_count += 1
        _safe_print("  [OK] Registered knowledge_intelligence blueprint")
    except ImportError:
        # Try alternative import name
        try:
            from backend.routes.knowledge_intelligence_routes import knowledge_intelligence_bp
            app.register_blueprint(knowledge_intelligence_bp)
            registered_count += 1
            _safe_print("  [OK] Registered knowledge_intelligence blueprint (alt)")
        except ImportError as e:
            _safe_print(f"  [WARN] Could not import knowledge_intelligence_routes: {e}")
            import traceback
            traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering knowledge_intelligence: {e}")
        import traceback
        traceback.print_exc()
    
    # Monetization routes
    try:
        from backend.routes.monetization_routes import monetization_bp
        app.register_blueprint(monetization_bp)
        registered_count += 1
        _safe_print("  [OK] Registered monetization blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import monetization_routes: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering monetization: {e}")
        import traceback
    
    # V3 Monetization Integration routes
    try:
        from backend.routes.v3_monetization_routes import v3_monetization_bp
        app.register_blueprint(v3_monetization_bp)
        registered_count += 1
        _safe_print("  [OK] Registered v3_monetization blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import v3_monetization_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering v3_monetization: {e}")
        traceback.print_exc()
    
    # Tech Tree Routes
    try:
        from backend.routes.tech_tree_routes import tech_tree_bp
        app.register_blueprint(tech_tree_bp)
        registered_count += 1
        _safe_print("  [OK] Registered tech_tree blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import tech_tree_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering tech_tree: {e}")
    
    # Victory Tech Tree Routes
    try:
        from backend.routes.victory_tech_tree import victory_tech_tree_bp
        app.register_blueprint(victory_tech_tree_bp)
        registered_count += 1
        _safe_print("  [OK] Registered victory_tech_tree blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import victory_tech_tree: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering victory_tech_tree: {e}")
    
    # Danish Giga Divine Tech Tree Routes
    try:
        from backend.routes.danish_divine_tech_tree import danish_divine_tech_tree_bp
        app.register_blueprint(danish_divine_tech_tree_bp)
        registered_count += 1
        _safe_print("  [OK] Registered danish_divine_tech_tree blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import danish_divine_tech_tree: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering danish_divine_tech_tree: {e}")
        traceback.print_exc()
    
    # All Page Routes - Unified route handler for all HTML pages
    try:
        from backend.routes.all_page_routes import all_page_routes_bp
        # No url_prefix - middleware already strips /vidgenerator
        app.register_blueprint(all_page_routes_bp)
        registered_count += 1
        _safe_print("  [OK] Registered all_page_routes blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import all_page_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering all_page_routes: {e}")
        traceback.print_exc()
    
    # Tech Debug Routes
    try:
        from backend.routes.tech_debug_routes import tech_debug_bp
        app.register_blueprint(tech_debug_bp)
        registered_count += 1
        _safe_print("  [OK] Registered tech_debug blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import tech_debug_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering tech_debug: {e}")
        traceback.print_exc()
    
    # Missing Page Routes (Social, Shop, Battle HTML)
    try:
        from backend.routes.missing_page_routes import social_page_bp, shop_page_bp, battle_page_bp
        app.register_blueprint(social_page_bp)
        app.register_blueprint(shop_page_bp)
        app.register_blueprint(battle_page_bp)
        registered_count += 3
        _safe_print("  [OK] Registered missing_page_routes (social, shop, battle)")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import missing_page_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering missing_page_routes: {e}")
        traceback.print_exc()
    
    # Video Editor Routes
    try:
        from backend.routes.video_editor_routes import video_editor_bp
        app.register_blueprint(video_editor_bp)
        registered_count += 1
        _safe_print("  [OK] Registered video_editor blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import video_editor_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering video_editor: {e}")
        traceback.print_exc()
    
    # Spider Web Error Handler routes
    try:
        from backend.routes.spiderweb_error_routes import spiderweb_error_bp
        app.register_blueprint(spiderweb_error_bp)
        registered_count += 1
        _safe_print("  [OK] Registered spiderweb_error blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import spiderweb_error_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering spiderweb_error: {e}")
        import traceback
        traceback.print_exc()
    
    # DNA Manipulation and Monster Calendar routes
    try:
        from backend.routes.dna_monster_calendar_routes import dna_monster_calendar_bp
        app.register_blueprint(dna_monster_calendar_bp)
        registered_count += 1
        _safe_print("  [OK] Registered dna_monster_calendar blueprint")
    except ImportError as e:
        _safe_print(f"  [WARN] Could not import dna_monster_calendar_routes: {e}")
    except Exception as e:
        _safe_print(f"  [ERROR] Error registering dna_monster_calendar: {e}")
        import traceback
        traceback.print_exc()
    
    _safe_print(f"[Backend] Registered {registered_count} blueprint groups")
    return registered_count

