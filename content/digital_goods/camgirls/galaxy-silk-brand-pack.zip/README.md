# Galaxy Silk brand pack

Includes icon, logo, gallery stills (WebP), preview clip, resell-pack.json.
Drop your own gallery-*.webp|png|jpg in this folder and re-run the generator.
Affiliate use requires disclosure per MasterNoder camgirls license.
